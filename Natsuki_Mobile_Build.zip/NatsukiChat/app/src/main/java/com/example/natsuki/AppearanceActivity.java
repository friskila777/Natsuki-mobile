package com.example.natsuki;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class AppearanceActivity extends Activity {
    ImageView preview;
    int hair = 0, expression = 0;
    int[] imgs = {R.drawable.natsuki_avatar, R.drawable.natsuki_happy, R.drawable.natsuki_angry, R.drawable.natsuki_shy};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(255,248,252));

        TextView title = new TextView(this);
        title.setText("Personalizar a Natsuki");
        title.setTextSize(24); title.setTextColor(Color.rgb(80,35,60));
        root.addView(title);

        preview = new ImageView(this);
        preview.setImageResource(imgs[expression]);
        preview.setPadding(20,20,20,20);
        root.addView(preview, new LinearLayout.LayoutParams(-1,240));

        TextView exp = new TextView(this); exp.setText("Expressão"); exp.setTextSize(18);
        root.addView(exp);
        LinearLayout row = new LinearLayout(this);
        String[] names={"Normal","Feliz","Brava","Tímida"};
        for(int i=0;i<names.length;i++){
            final int k=i; Button bt=new Button(this); bt.setText(names[i]);
            bt.setOnClickListener(v->{expression=k; preview.setImageResource(imgs[k]);});
            row.addView(bt,new LinearLayout.LayoutParams(0,60,1));
        }
        root.addView(row);

        TextView hairTitle = new TextView(this); hairTitle.setText("Cor do tema / cabelo"); hairTitle.setTextSize(18);
        root.addView(hairTitle);
        SeekBar hue = new SeekBar(this); hue.setMax(100); hue.setProgress(55);
        hue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){
                int c=Color.HSVToColor(new float[]{p*3.6f,0.48f,1f});
                preview.setColorFilter(c, android.graphics.PorterDuff.Mode.MULTIPLY);
            }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        });
        root.addView(hue);

        Button save = new Button(this); save.setText("Salvar aparência");
        save.setOnClickListener(v->{ getPreferences(0).edit().putInt("expr",expression).apply(); Toast.makeText(this,"Aparência salva!",Toast.LENGTH_SHORT).show();});
        root.addView(save);

        setContentView(root);
    }
}
