package com.example.natsuki;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
 LinearLayout messages; EditText input; ImageView avatar; NatsukiTTS tts; LLMClient llm;
 ArrayList<org.json.JSONObject> history=new ArrayList<>();ArrayList<String> memories=new ArrayList<>();
 boolean speakReplies=true,aiEnabled=true;int pink=Color.rgb(255,126,182);String backendUrl;
 int[] faces={R.drawable.natsuki_avatar,R.drawable.natsuki_happy,R.drawable.natsuki_angry,R.drawable.natsuki_shy};

 @Override public void onCreate(Bundle b){
  super.onCreate(b);backendUrl=getPreferences(0).getString("backend_url","http://10.0.2.2:3000");
  llm=new LLMClient(backendUrl);tts=new NatsukiTTS(this);loadMemories();
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},20);
  buildUi();
 }

 TextView bubble(String text,boolean n){TextView t=new TextView(this);t.setText(text);t.setTextSize(16);t.setTextColor(Color.rgb(51,35,45));t.setPadding(24,16,24,16);
  GradientDrawable g=new GradientDrawable();g.setColor(n?Color.rgb(255,240,247):Color.rgb(240,230,238));g.setCornerRadius(28);t.setBackground(g);
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(12,8,12,8);t.setLayoutParams(p);return t;}

 void buildUi(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(255,248,252));
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(12,8,12,8);head.setBackgroundColor(pink);
  avatar=new ImageView(this);avatar.setImageResource(faces[0]);head.addView(avatar,new LinearLayout.LayoutParams(64,64));
  TextView title=new TextView(this);title.setText("  Natsuki");title.setTextSize(22);title.setTextColor(Color.WHITE);head.addView(title,new LinearLayout.LayoutParams(0,72,1));
  Switch voice=new Switch(this);voice.setText("🔊");voice.setTextColor(Color.WHITE);voice.setChecked(true);voice.setOnCheckedChangeListener((x,c)->speakReplies=c);head.addView(voice);root.addView(head);
  messages=new LinearLayout(this);messages.setOrientation(LinearLayout.VERTICAL);ScrollView scroll=new ScrollView(this);scroll.addView(messages);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout bar=new LinearLayout(this);bar.setPadding(8,8,8,8);input=new EditText(this);input.setHint("Escreva ou fale com a Natsuki...");bar.addView(input,new LinearLayout.LayoutParams(0,64,1));
  Button mic=new Button(this);mic.setText("🎙");bar.addView(mic,new LinearLayout.LayoutParams(64,64));Button send=new Button(this);send.setText("➤");bar.addView(send,new LinearLayout.LayoutParams(64,64));root.addView(bar);
  LinearLayout tools=new LinearLayout(this);Button appearance=new Button(this);appearance.setText("🎨 Aparência");Button pet=new Button(this);pet.setText("🌸 Bonequinha");Button settings=new Button(this);settings.setText("⚙️ LLM");
  tools.addView(appearance,new LinearLayout.LayoutParams(0,62,1));tools.addView(pet,new LinearLayout.LayoutParams(0,62,1));tools.addView(settings,new LinearLayout.LayoutParams(0,62,1));root.addView(tools);
  send.setOnClickListener(v->sendText());mic.setOnClickListener(v->startVoice());appearance.setOnClickListener(v->startActivity(new Intent(this,AppearanceActivity.class)));pet.setOnClickListener(v->activatePet());settings.setOnClickListener(v->configureLLM());
  setContentView(root);messages.addView(bubble("Hmph! Agora eu tenho humor, memória e até atuação. Não se acostuma com tanto esforço!",true));
 }

 void sendText(){
  String s=input.getText().toString().trim();if(s.isEmpty())return;messages.addView(bubble(s,false));input.setText("");
  if(!aiEnabled){replyLocal(s);return;}messages.addView(bubble("...Natsuki está pensando...",true));
  try{
   org.json.JSONArray a=new org.json.JSONArray();for(org.json.JSONObject x:history)a.put(x);
   org.json.JSONArray m=new org.json.JSONArray();for(String x:memories)m.put(x);
   llm.chat(s,a.toString(),m.toString(),(state,error)->{
    if(messages.getChildCount()>0)messages.removeViewAt(messages.getChildCount()-1);
    if(error!=null){replyLocal(s);Toast.makeText(this,"LLM indisponível; modo local.",Toast.LENGTH_LONG).show();return;}
    applyState(state);try{
      history.add(new org.json.JSONObject().put("role","user").put("content",s));
      history.add(new org.json.JSONObject().put("role","assistant").put("content",state.reply));
      if(state.memory!=null&&!state.memory.trim().isEmpty()&&!memories.contains(state.memory)){memories.add(state.memory);saveMemories();}
    }catch(Exception ignored){}
    messages.addView(bubble(state.reply,true));if(speakReplies&&state.voiceEnabled)tts.speak(state.reply,state.rate,state.pitch);
   });
  }catch(Exception e){replyLocal(s);}
 }

 void applyState(NatsukiState s){
  int idx=0;
  if("happy".equals(s.mood)||"excited".equals(s.mood))idx=1;
  else if("angry".equals(s.mood))idx=2;
  else if("shy".equals(s.mood))idx=3;
  avatar.setImageResource(faces[idx]);
  float tx=0;
  if("left".equals(s.gaze))tx=-10;else if("right".equals(s.gaze))tx=10;
  avatar.setTranslationX(tx);
  avatar.setAlpha("closed".equals(s.gaze) ? 0.8f : 1f);
  switch(s.animation){
   case "bounce": avatar.animate().translationY(-14).setDuration(160).withEndAction(()->avatar.animate().translationY(0).setDuration(160)).start();break;
   case "shake": avatar.animate().rotationBy(12).setDuration(70).withEndAction(()->avatar.animate().rotationBy(-24).setDuration(140).withEndAction(()->avatar.animate().rotationBy(12).setDuration(70))).start();break;
   case "blush": avatar.animate().scaleX(1.08f).scaleY(1.08f).setDuration(220).withEndAction(()->avatar.animate().scaleX(1).scaleY(1).setDuration(220)).start();break;
   case "surprised": avatar.animate().scaleX(1.15f).scaleY(1.15f).setDuration(100).withEndAction(()->avatar.animate().scaleX(1).scaleY(1).setDuration(180)).start();break;
   default: avatar.animate().rotationBy(6).setDuration(100).withEndAction(()->avatar.animate().rotationBy(-6).setDuration(100)).start();
  }
 }

 void replyLocal(String s){String r=ChatEngine.reply(s);messages.addView(bubble(r,true));if(speakReplies)tts.speak(r);}

 void configureLLM(){
  final EditText url=new EditText(this);url.setText(backendUrl);
  new AlertDialog.Builder(this).setTitle("Servidor LLM").setMessage("Use o endereço do seu backend. A chave da API nunca deve ser colocada aqui.")
   .setView(url).setPositiveButton("Salvar",(d,w)->{backendUrl=url.getText().toString().trim();getPreferences(0).edit().putString("backend_url",backendUrl).apply();llm=new LLMClient(backendUrl);})
   .setNegativeButton("Cancelar",null).show();
 }

 void loadMemories(){String s=getPreferences(0).getString("memories","[]");try{org.json.JSONArray a=new org.json.JSONArray(s);for(int i=0;i<a.length();i++)memories.add(a.getString(i));}catch(Exception ignored){}}
 void saveMemories(){try{org.json.JSONArray a=new org.json.JSONArray();for(String x:memories)a.put(x);getPreferences(0).edit().putString("memories",a.toString()).apply();}catch(Exception ignored){}}

 void startVoice(){Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");try{startActivityForResult(i,30);}catch(Exception e){Toast.makeText(this,"Voz indisponível.",Toast.LENGTH_SHORT).show();}}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==30&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty()){input.setText(x.get(0));sendText();}}}
 void activatePet(){if(!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));else startForegroundService(new Intent(this,PetOverlayService.class));}
 @Override protected void onDestroy(){if(tts!=null)tts.release();super.onDestroy();}
}
