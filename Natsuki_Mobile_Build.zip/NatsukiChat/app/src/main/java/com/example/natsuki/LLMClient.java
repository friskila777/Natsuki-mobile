package com.example.natsuki;

import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class LLMClient {
 public interface Callback { void done(NatsukiState state, Exception error); }
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private final Handler main=new Handler(Looper.getMainLooper());
 private String baseUrl;
 public LLMClient(String url){baseUrl=url.endsWith("/")?url.substring(0,url.length()-1):url;}

 public void chat(String userText,String historyJson,String memoriesJson,Callback cb){
  executor.execute(()->{
   try{
    HttpURLConnection c=(HttpURLConnection)new URL(baseUrl+"/chat").openConnection();
    c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(60000);c.setDoOutput(true);
    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
    JSONObject body=new JSONObject();body.put("message",userText);
    body.put("history",new JSONArray(historyJson));body.put("memories",new JSONArray(memoriesJson));
    try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
    int code=c.getResponseCode();
    InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
    String raw=read(is);
    if(code<200||code>=300)throw new IOException("HTTP "+code+": "+raw);
    JSONObject j=new JSONObject(raw);
    NatsukiState s=NatsukiState.from(j);
    main.post(()->cb.done(s,null));
   }catch(Exception e){main.post(()->cb.done(null,e));}
  });
 }
 private String read(InputStream in)throws Exception{
  StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
   String line;while((line=r.readLine())!=null)s.append(line);
  }return s.toString();
 }
}
