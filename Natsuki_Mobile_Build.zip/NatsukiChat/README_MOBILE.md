# Natsuki Mobile Build

Projeto Android da Natsuki preparado para gerar APK por compilação na nuvem,
sem Android Studio e sem computador próprio.

O arquivo `.github/workflows/android-apk.yml` configura o GitHub Actions para
executar o Gradle e publicar o APK como artefato baixável.
