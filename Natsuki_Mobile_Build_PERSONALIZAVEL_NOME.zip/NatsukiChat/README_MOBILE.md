# Natsuki Mobile Build

Projeto Android da Natsuki preparado para gerar APK por compilação na nuvem,
sem Android Studio e sem computador próprio.

O arquivo `.github/workflows/android-apk.yml` configura o GitHub Actions para
executar o Gradle e publicar o APK como artefato baixável.


## Correção LLM/Render
- O cliente Android agora tolera serviços Render acordando após inatividade, com timeout maior.
- A tela ⚙️ LLM ganhou o botão **Testar**, que consulta `/health`.
- Erros HTTP/conexão agora aparecem no Toast para facilitar diagnóstico.
- A URL padrão não é mais `localhost`; informe a URL pública `https://...onrender.com`.

## Personalização de imagem
- Em **🎨 Personalizar**, agora é possível escolher qualquer imagem do celular.
- A imagem escolhida substitui a bonequinha padrão no chat e no pet flutuante.
- A imagem fica salva no aparelho e continua após fechar/reabrir o app.
- As animações continuam funcionando sobre a imagem escolhida.
- O hub de botões foi movido para logo abaixo do cabeçalho, ficando acessível mesmo quando o teclado estiver aberto.

## Nome/apelido do usuário
- Em **💜 Como me chama**, o usuário escolhe como Natsuki deve chamá-lo.
- O apelido é salvo localmente.
- A preferência é enviada ao LLM junto da mensagem para manter o tratamento escolhido.
- Também há o mesmo controle dentro de **🎨 Personalizar**.
