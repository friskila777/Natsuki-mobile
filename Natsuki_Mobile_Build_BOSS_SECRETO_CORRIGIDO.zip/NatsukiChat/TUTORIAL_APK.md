# Tutorial completo — Natsuki viva + LLM + APK

## Parte A — o que você precisa

No computador:
1. Android Studio.
2. JDK/SDK instalados pelo Android Studio.
3. Node.js.
4. Uma chave de API da OpenAI.
5. O ZIP deste projeto.

O Android Studio é a IDE oficial para Android e usa Gradle para compilar o projeto. A documentação oficial explica como importar projetos existentes e gerar APKs. 

## Parte B — configurar o cérebro da Natsuki

1. Extraia `NatsukiChat_LLM.zip`.
2. Abra um terminal dentro da pasta `backend`.
3. Rode:
   `npm install`
4. Copie `.env.example` para `.env`.
5. Abra `.env`.
6. Coloque sua chave:
   `OPENAI_API_KEY=sua_chave`
7. Deixe:
   `OPENAI_MODEL=gpt-5.6-luna`
8. Rode:
   `npm start`

Você deverá ver:
`Natsuki LLM server em http://localhost:3000`

NUNCA coloque a chave da API no código Android ou dentro do APK.

## Parte C — testar o servidor

Abra no navegador do computador:
`http://localhost:3000/health`

Deve aparecer algo parecido com:
`{"ok":true,"character":"Natsuki"}`

## Parte D — conectar o Android

### Se estiver usando o Android Emulator
No aplicativo:
1. Abra Natsuki.
2. Toque em `⚙️ LLM`.
3. Use:
   `http://10.0.2.2:3000`

`10.0.2.2` é o endereço especial usado pelo emulador para acessar o computador host.

### Se estiver usando um celular
1. Computador e celular devem estar na mesma rede Wi-Fi.
2. Descubra o IP local do computador, por exemplo `192.168.1.10`.
3. No app coloque:
   `http://192.168.1.10:3000`
4. Se o Windows/Linux/macOS perguntar sobre firewall, permita o Node.js na rede privada/local.
5. Teste no navegador do celular:
   `http://192.168.1.10:3000/health`

## Parte E — como a Natsuki fica "viva"

O LLM não devolve somente texto.

Ele devolve um estado estruturado:

- `reply` — o que ela fala.
- `mood` — normal, feliz, brava, tímida, triste, animada, sonolenta ou carinhosa.
- `animation` — movimento da personagem.
- `gaze` — direção do olhar.
- `voice` — velocidade e tom da voz.
- `affection_delta` — mudança de afinidade.
- `memory` — uma memória importante que pode ser guardada.

Exemplo conceitual:

Usuário:
`Eu gosto muito de você.`

Natsuki pode retornar:
- reply: resposta envergonhada
- mood: `shy`
- animation: `blush`
- gaze: `down`
- voice.pitch: mais alto
- voice.rate: um pouco mais lento
- affection_delta: `2`
- memory: `O usuário declarou que gosta muito da Natsuki.`

O Android usa esses dados para trocar o avatar, animar, mudar olhar e alterar o TTS.

## Parte F — memória

A versão atual mantém memórias simples localmente no aplicativo.

O fluxo é:
1. O LLM decide se algo é uma memória importante.
2. O backend devolve o campo `memory`.
3. O Android salva essa memória localmente.
4. Em conversas futuras, as memórias são enviadas ao LLM.
5. A Natsuki pode usar isso para manter continuidade.

Para uma versão grande, recomendo migrar depois para banco de dados com embeddings/recuperação semântica, em vez de mandar todas as memórias sempre.

## Parte G — gerar o APK

1. Abra o Android Studio.
2. Escolha **Open**.
3. Selecione a pasta extraída `NatsukiChat`.
4. Aguarde o Gradle sincronizar.
5. Se aparecer uma solicitação de SDK, instale a versão indicada.
6. Escolha `app` como configuração.
7. Execute primeiro no celular/emulador para testar.
8. Para gerar APK de teste:
   **Build → Build APK(s)**.
9. O Android Studio mostrará onde o APK foi criado.

A documentação do Android confirma que o sistema de build compila código/recursos e empacota o resultado como APK ou App Bundle. citeturn0search3turn0search0

## Parte H — APK de lançamento

Para distribuir o aplicativo:
1. **Build → Generate Signed Bundle / APK**.
2. Escolha `APK`.
3. Crie ou selecione uma keystore.
4. Guarde a senha e o arquivo da keystore em local seguro.
5. Escolha `release`.
6. Gere o APK.

O Android exige assinatura para APKs instaláveis de lançamento; o build de debug recebe uma assinatura de desenvolvimento automaticamente, enquanto o release precisa de configuração de assinatura. citeturn0search0turn0search7

## Parte I — permissões no celular

Ao abrir a Natsuki pela primeira vez:
- permita microfone;
- permita aparecer sobre outros apps para usar a bonequinha;
- permita notificações se o Android solicitar.

Depois:
1. Abra `🎨 Aparência` para personalizar.
2. Ative `🌸 Bonequinha`.
3. Toque duas vezes na bonequinha para retornar ao app.
4. Segure para o efeito de cafuné.
5. Use `🔊` para ativar/desativar voz.
6. Use `⚙️ LLM` para alterar o servidor.

## Problemas comuns

### "LLM indisponível"
Verifique:
- `npm start` está rodando;
- `/health` funciona;
- o endereço no aplicativo está correto;
- celular e computador estão na mesma rede;
- firewall não está bloqueando a porta 3000.

### O emulador não acessa localhost
Não use `localhost` no Android Emulator. Use:
`http://10.0.2.2:3000`

### O celular não acessa o servidor
Use o IP LAN do computador:
`http://SEU_IP:3000`

### A voz não funciona
Verifique microfone e o mecanismo de Text-to-Speech instalado no Android.

### Quero publicar na internet
Não exponha o servidor de desenvolvimento diretamente. Use HTTPS, autenticação, rate limiting e controles de custo.
