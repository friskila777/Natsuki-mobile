# Backend LLM da Natsuki

O aplicativo Android **não** chama a OpenAI diretamente. Isso é intencional: chaves de API são segredos e não devem ser embutidas em apps cliente. O backend guarda `OPENAI_API_KEY` no servidor.

## 1. Instalar
Requer Node.js.

```bash
npm install
```

## 2. Configurar
Copie `.env.example` para `.env` e coloque sua chave:

```text
OPENAI_API_KEY=sua_chave
OPENAI_MODEL=gpt-5.6-luna
PORT=3000
```

## 3. Executar

```bash
npm start
```

O servidor ficará em `http://localhost:3000`.

## 4. Ligar o Android

No emulador Android, o endereço padrão para o computador é:

`http://10.0.2.2:3000`

No celular físico, coloque o IP local do computador na mesma rede, por exemplo:

`http://192.168.1.10:3000`

No app, toque em **⚙️ LLM** e informe esse endereço.

## Segurança

Para uso real na internet, coloque o servidor atrás de HTTPS, autenticação e limites de uso. Não coloque a `OPENAI_API_KEY` no APK.
