# Natsuki Chat — LLM

Agora o projeto inclui um backend para conectar a Natsuki a um modelo de linguagem via OpenAI Responses API.

## Arquitetura
Android → seu backend `/chat` → OpenAI Responses API → Natsuki.

A chave fica somente no backend. A documentação da OpenAI recomenda não expor chaves em código cliente; elas devem ser mantidas no servidor/ambiente seguro. cite não é incluído no arquivo.

## Passos
1. Entre na pasta `backend`.
2. Execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Defina `OPENAI_API_KEY`.
5. Execute `npm start`.
6. Abra o app.
7. Toque em `⚙️ LLM`.
8. No emulador use `http://10.0.2.2:3000`.
9. No celular real use o IP do computador na rede local.
10. Converse normalmente.

O modelo padrão configurado é `gpt-5.6-luna`; você pode mudar `OPENAI_MODEL` no `.env`.

## Observação
O app mantém um histórico recente e o envia ao backend para continuidade da conversa. O backend injeta a personalidade da Natsuki como instrução de desenvolvedor.

Ainda não é um serviço público pronto para produção: antes de expor na internet, adicione autenticação, HTTPS, rate limiting e controles de custo.
