package com.example.natsuki;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class AppearanceActivity extends Activity {
    private static final int PICK_IMAGE = 41;
    ImageView preview;
    int expression = 0;
    int[] imgs = {R.drawable.natsuki_avatar, R.drawable.natsuki_happy, R.drawable.natsuki_angry, R.drawable.natsuki_shy};
    Uri customUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(255,248,252));

        TextView title = new TextView(this);
        title.setText("Personalizar a Natsuki");
        title.setTextSize(24); title.setTextColor(Color.rgb(80,35,60));
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Você pode usar qualquer imagem do seu celular como a bonequinha.");
        info.setTextSize(15);
        info.setPadding(0,8,0,8);
        root.addView(info);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        preview.setImageResource(imgs[expression]);
        preview.setPadding(10,10,10,10);
        root.addView(preview, new LinearLayout.LayoutParams(-1,260));

        Button choose = new Button(this);
        choose.setText("🖼️ Escolher imagem do celular");
        choose.setOnClickListener(v -> pickImage());
        root.addView(choose, new LinearLayout.LayoutParams(-1,64));

        Button remove = new Button(this);
        remove.setText("↩️ Voltar para a Natsuki padrão");
        remove.setOnClickListener(v -> {
            customUri = null;
            preview.setImageResource(imgs[expression]);
        });
        root.addView(remove, new LinearLayout.LayoutParams(-1,58));

        TextView exp = new TextView(this);
        exp.setText("Expressão padrão (quando não houver imagem personalizada)");
        exp.setTextSize(17);
        exp.setPadding(0,14,0,4);
        root.addView(exp);

        LinearLayout row = new LinearLayout(this);
        String[] names={"Normal","Feliz","Brava","Tímida"};
        for(int i=0;i<names.length;i++){
            final int k=i;
            Button bt=new Button(this); bt.setText(names[i]);
            bt.setOnClickListener(v->{
                expression=k;
                if(customUri==null) preview.setImageResource(imgs[k]);
            });
            row.addView(bt,new LinearLayout.LayoutParams(0,60,1));
        }
        root.addView(row);

        TextView note = new TextView(this);
        note.setText("A imagem personalizada substitui a bonequinha padrão. As animações do chat continuam funcionando.");
        note.setTextSize(14);
        note.setPadding(0,12,0,8);
        root.addView(note);

        Button callName = new Button(this);
        callName.setText("💜 Escolher como ela te chama");
        callName.setOnClickListener(v -> {
            final EditText name = new EditText(this);
            name.setSingleLine(true);
            name.setHint("Ex.: Friskila, chefe, amor...");
            name.setText(getSharedPreferences("NatsukiPrefs",MODE_PRIVATE).getString("call_name",""));
            new android.app.AlertDialog.Builder(this)
                .setTitle("Como Natsuki vai te chamar?")
                .setView(name)
                .setPositiveButton("Salvar", (d,w) -> {
                    getSharedPreferences("NatsukiPrefs",MODE_PRIVATE).edit().putString("call_name",name.getText().toString().trim()).apply();
                    Toast.makeText(this,"Apelido salvo! 💜",Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar",null).show();
        });
        root.addView(callName, new LinearLayout.LayoutParams(-1,64));

        Button save = new Button(this);
        save.setText("💾 Salvar aparência");
        save.setOnClickListener(v -> {
            SharedPreferences.Editor e=getSharedPreferences("NatsukiAppearance",MODE_PRIVATE).edit();
            e.putInt("expr",expression);
            if(customUri!=null) e.putString("custom_image_uri",customUri.toString());
            else e.remove("custom_image_uri");
            e.apply();
            Toast.makeText(this,"Aparência salva!",Toast.LENGTH_SHORT).show();
            finish();
        });
        root.addView(save, new LinearLayout.LayoutParams(-1,64));

        loadSaved();
        setContentView(root);
    }

    void loadSaved(){
        SharedPreferences p=getSharedPreferences("NatsukiAppearance",MODE_PRIVATE);
        expression=p.getInt("expr",0);
        String s=p.getString("custom_image_uri","");
        if(s!=null&&!s.isEmpty()){
            try{
                customUri=Uri.parse(s);
                preview.setImageURI(customUri);
            }catch(Exception e){
                customUri=null;
                preview.setImageResource(imgs[expression]);
            }
        }else{
            preview.setImageResource(imgs[expression]);
        }
    }

    void pickImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_IMAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            customUri=data.getData();
            try{
                getContentResolver().takePersistableUriPermission(
                    customUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }catch(Exception ignored){}
            preview.setImageURI(customUri);
        }
    }
}
