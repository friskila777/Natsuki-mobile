package com.example.natsuki;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class PetOverlayService extends Service {
    WindowManager wm; ImageView pet; Handler h=new Handler(Looper.getMainLooper());
    long lastTap=0; Runnable caress;

    @Override public void onCreate(){
        super.onCreate(); createChannel();
        startForeground(7,new Notification.Builder(this,"natsuki")
            .setContentTitle("Natsuki está por perto")
            .setContentText("Toque duas vezes na bonequinha para abrir o chat.")
            .setSmallIcon(R.drawable.natsuki_avatar).build());
        showPet();
    }

    void showPet(){
        if(!Settings.canDrawOverlays(this))return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        pet=new ImageView(this);
        pet.setPadding(4,4,4,4);
        loadPetImage();
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(110,110,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.BOTTOM|Gravity.RIGHT; p.x=20;p.y=120;

        pet.setOnTouchListener(new View.OnTouchListener(){
            float sx,sy;int ox,oy;boolean moving;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){
                    sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;moving=false;
                    long now=System.currentTimeMillis();
                    if(now-lastTap<350){openApp();lastTap=0;return true;}
                    lastTap=now;
                    caress=()->{
                        pet.setImageResource(R.drawable.natsuki_shy);
                        pet.animate().scaleX(1.18f).scaleY(1.18f).setDuration(180).start();
                        Toast.makeText(PetOverlayService.this,"M-mas não para...!",Toast.LENGTH_SHORT).show();
                    };
                    h.postDelayed(caress,500);
                    return true;
                }
                if(e.getAction()==MotionEvent.ACTION_MOVE){
                    if(Math.abs(e.getRawX()-sx)>8||Math.abs(e.getRawY()-sy)>8)moving=true;
                    p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(sy-e.getRawY());wm.updateViewLayout(pet,p);return true;
                }
                if(e.getAction()==MotionEvent.ACTION_UP){
                    if(caress!=null)h.removeCallbacks(caress);
                    pet.animate().scaleX(1).scaleY(1).setDuration(120).start();
                    if(!moving){h.postDelayed(()->loadPetImage(),900);}
                    return true;
                }
                return true;
            }
        });
        wm.addView(pet,p);
    }

    void loadPetImage(){
        try{
            String uri=getSharedPreferences("NatsukiAppearance",MODE_PRIVATE)
                .getString("custom_image_uri","");
            if(uri!=null&&!uri.isEmpty()){
                pet.setImageURI(Uri.parse(uri));
                return;
            }
        }catch(Exception ignored){}
        pet.setImageResource(R.drawable.natsuki_avatar);
    }

    void openApp(){
        Intent i=new Intent(this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("natsuki","Natsuki",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(pet!=null&&wm!=null)wm.removeView(pet);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
