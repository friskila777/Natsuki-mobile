package com.example.natsuki;

import android.os.*;
import android.util.Log;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public class LLMClient {
 public interface Callback { void done(NatsukiState state, Exception error); }

 private static final String TAG="NatsukiLLM";
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private final Handler main=new Handler(Looper.getMainLooper());
 private final String baseUrl;

 public LLMClient(String url){
  String u=(url==null?"":url).trim();
  while(u.endsWith("/")) u=u.substring(0,u.length()-1);
  baseUrl=u;
 }

 public void chat(String userText,String historyJson,String memoriesJson,Callback cb){
  executor.execute(()->{
   HttpURLConnection c=null;
   try{
    if(baseUrl.isEmpty()) throw new IOException("URL do backend vazia.");
    URL endpoint=new URL(baseUrl+"/chat");
    c=(HttpURLConnection)endpoint.openConnection();
    c.setRequestMethod("POST");
    // Render pode estar "acordando" um serviço que estava dormindo.
    c.setConnectTimeout(60000);
    c.setReadTimeout(120000);
    c.setDoOutput(true);
    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
    c.setRequestProperty("Accept","application/json");

    JSONObject body=new JSONObject();
    body.put("message",userText);
    body.put("history",new JSONArray(historyJson));
    body.put("memories",new JSONArray(memoriesJson));

    try(OutputStream out=c.getOutputStream()){
     out.write(body.toString().getBytes(StandardCharsets.UTF_8));
    }

    int code=c.getResponseCode();
    InputStream is=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
    String raw=read(is);

    if(code<200||code>=300){
     throw new IOException("HTTP "+code+(raw.isEmpty()?"":": "+raw));
    }

    JSONObject j=new JSONObject(raw);
    NatsukiState s=NatsukiState.from(j);
    if(s.reply==null||s.reply.trim().isEmpty())
     throw new IOException("O backend retornou uma resposta vazia.");

    main.post(()->cb.done(s,null));
   }catch(Exception e){
    Log.e(TAG,"Falha ao chamar "+baseUrl+"/chat",e);
    main.post(()->cb.done(null,e));
   }finally{
    if(c!=null)c.disconnect();
   }
  });
 }

 private String read(InputStream in)throws Exception{
  if(in==null)return "";
  StringBuilder s=new StringBuilder();
  try(BufferedReader r=new BufferedReader(
      new InputStreamReader(in,StandardCharsets.UTF_8))){
   String line;
   while((line=r.readLine())!=null)s.append(line);
  }
  return s.toString();
 }
}
