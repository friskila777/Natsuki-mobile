package com.example.natsuki;

import org.json.JSONObject;

public class NatsukiState {
 public String reply,mood,animation,gaze,memory;
 public boolean voiceEnabled;
 public float rate,pitch;
 public int affectionDelta;

 public static NatsukiState from(JSONObject j){
  NatsukiState s=new NatsukiState();
  s.reply=j.optString("reply","");
  s.mood=j.optString("mood","normal");
  s.animation=j.optString("animation","idle");
  s.gaze=j.optString("gaze","center");
  JSONObject v=j.optJSONObject("voice");
  s.voiceEnabled=v==null||v.optBoolean("enabled",true);
  s.rate=v==null?1.05f:(float)v.optDouble("rate",1.05);
  s.pitch=v==null?1.18f:(float)v.optDouble("pitch",1.18);
  s.affectionDelta=j.optInt("affection_delta",0);
  s.memory=j.optString("memory","");
  return s;
 }
}
