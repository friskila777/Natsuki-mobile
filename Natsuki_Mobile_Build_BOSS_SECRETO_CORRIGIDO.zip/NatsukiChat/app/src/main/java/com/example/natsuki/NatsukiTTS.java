package com.example.natsuki;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class NatsukiTTS {
 private TextToSpeech tts; private boolean ready=false;
 public NatsukiTTS(Context c){
  tts=new TextToSpeech(c,status->{
   if(status==TextToSpeech.SUCCESS){
    int r=tts.setLanguage(new Locale("pt","BR"));
    ready=r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED;
    tts.setSpeechRate(1.05f);tts.setPitch(1.18f);
   }
  });
 }
 public void speak(String text,float rate,float pitch){
  if(!ready)return;
  tts.setSpeechRate(Math.max(.65f,Math.min(1.6f,rate)));
  tts.setPitch(Math.max(.65f,Math.min(1.7f,pitch)));
  tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"natsuki_reply");
 }
 public void speak(String text){speak(text,1.05f,1.18f);}
 public void stop(){if(tts!=null)tts.stop();}
 public void release(){if(tts!=null)tts.shutdown();}
}
