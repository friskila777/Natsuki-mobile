package com.example.natsuki;

import java.util.Locale;
import java.util.Random;

public class ChatEngine {
    private static final Random R = new Random();
    private static int affinity = 0;
    private static String mood = "normal";

    public static String reply(String input) {
        String s = input.toLowerCase(Locale.ROOT).trim();

        if (s.isEmpty()) return "Vai falar comigo ou só ficar me encarando? B-baka...";

        if (s.contains("obrigad")) { affinity++; mood="happy"; return pick(
            "Hmph. Não fiz isso por você nem nada... mas de nada.",
            "Você agradeceu? ...Tá. Isso foi fofo. Só um pouquinho."
        );}

        if (s.contains("amo você") || s.contains("amo voce") || s.contains("te amo")) {
            affinity += 2; mood="shy";
            return pick(
                "Q-QUÊ?! Não joga uma dessas em cima de mim do nada!",
                "Eu... eu também gosto de você, tá?! Mas não se ache por causa disso!"
            );
        }

        if (s.contains("triste") || s.contains("chor") || s.contains("mal")) {
            mood="soft"; affinity++;
            return "Ei... vem cá. Você não precisa fingir que está bem comigo. " +
                   (affinity > 5 ? "Eu fico aqui com você, ouviu?" : "Só... não fica sozinho com isso.");
        }

        if (s.contains("cafun") || s.contains("carinho")) {
            mood="shy"; affinity++;
            return "M-mão na minha cabeça?! ...Tá. Só por um pouquinho. " +
                   (affinity > 4 ? "Não para ainda..." : "E não conta pra ninguém!");
        }

        if (s.contains("oi") || s.contains("olá") || s.contains("ola")) {
            mood="happy";
            return pick("O-oi! Eu não estava esperando você... não que eu estivesse esperando!",
                        "Finalmente apareceu! Eu já estava quase indo embora. Quase.");
        }

        if (s.contains("quem é você") || s.contains("quem e voce")) {
            return "Eu sou a Natsuki. Sua parceira de RP. Posso ser fofa, brava, dramática ou implicante. " +
                   "Mas você vai ter que acompanhar a história.";
        }

        if (s.contains("vamos") || s.contains("rp") || s.contains("roleplay") || s.contains("cena")) {
            mood="happy";
            return "Tá bom! Então descreve a cena. Eu entro no personagem e você interpreta o seu.";
        }

        if (s.endsWith("?")) {
            mood="normal";
            return pick("Hã? Boa pergunta... deixa eu pensar antes de responder.",
                        "Você pergunta cada coisa! Mas tá, eu respondo.");
        }

        // RP contextual simples
        if (s.contains("*") || s.startsWith("(") || s.contains("entra") || s.contains("olha")) {
            mood="happy";
            return "*Natsuki cruza os braços, tentando esconder um sorriso.* \"Hmph. Então é isso que você decidiu fazer? Tudo bem... eu acompanho.\"";
        }

        return pick(
            "Hmph! " + input + " ...Interessante. Continua. Quero ver onde isso vai chegar.",
            "Tá, eu entendi. Agora desenvolve essa ideia direito, baka.",
            "*Natsuki inclina a cabeça.* \"E depois? Não me deixa esperando.\""
        );
    }

    public static String getMood() { return mood; }
    public static int getAffinity() { return affinity; }

    private static String pick(String... a) { return a[R.nextInt(a.length)]; }
}
