# Natsuki Mobile Build — gerar APK usando somente o celular

## Método recomendado: GitHub Actions

1. Abra o GitHub no navegador do celular e crie uma conta gratuita.
2. Crie um repositório novo, por exemplo `natsuki-mobile`.
3. Envie **todos os arquivos desta pasta**, mantendo as pastas `app`, `backend` e `.github`.
4. Abra a aba **Actions** do repositório.
5. Selecione **Gerar APK da Natsuki**.
6. Toque em **Run workflow** ou faça um pequeno commit para iniciar o processo.
7. Quando terminar com um símbolo verde, abra a execução.
8. Na seção **Artifacts**, toque em `Natsuki-debug-apk`.
9. Baixe o ZIP, extraia-o pelo gerenciador de arquivos e instale o `app-debug.apk`.

## Se o GitHub bloquear o workflow

Abra a aba Actions e habilite workflows para o repositório. Depois execute
novamente o workflow manualmente.

## Observações importantes

- Este pacote gera uma versão **debug**, adequada para testar no celular.
- Para usar a IA, o backend em `backend/` ainda precisa estar hospedado em algum
  serviço que execute Node.js. Não coloque a chave da API dentro do APK.
- A configuração HTTP foi deixada habilitada apenas para facilitar testes locais.
  Para publicar o aplicativo, use HTTPS.
- O modelo da API é configurado em `backend/.env`; o valor padrão atual é
  `gpt-5.6-luna`, mas ele deve ser substituído por um modelo disponível na sua
  conta caso necessário.
